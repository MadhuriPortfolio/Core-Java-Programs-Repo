package oops_abstraction;

public abstract class AbstractADemo {

    abstract int methodA();
    abstract void methodB();

    void methodDisplay(){
        System.out.println("this  is a sample method with implementation");
    }

     void methodDisplay1(){
        System.out.println("this  is a sample method with implementation");
    }
}
