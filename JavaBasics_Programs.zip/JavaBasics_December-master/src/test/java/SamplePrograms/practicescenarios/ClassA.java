package SamplePrograms.practicescenarios;

public class ClassA {

	public static void main(String[] args) {
		ClassB classb = new ClassB();
		System.out.println(classb.display("sample"));
	}

}
