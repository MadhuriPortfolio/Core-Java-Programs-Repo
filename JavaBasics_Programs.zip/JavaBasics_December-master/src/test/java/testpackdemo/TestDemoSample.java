package testpackdemo;

public class TestDemoSample {

    public void subtraction(){
        int a =8;
        int b =7;
        int result = a-b;
        System.out.println("the subtraction result : " + result);
    }
}
