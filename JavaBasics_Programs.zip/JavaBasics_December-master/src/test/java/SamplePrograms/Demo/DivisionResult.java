package SamplePrograms.Demo;

public class DivisionResult {

	public static void main(String[] args) {
		// this pulls the output
		int result = 4 / 2;
		System.out.println(result);
	}

}
