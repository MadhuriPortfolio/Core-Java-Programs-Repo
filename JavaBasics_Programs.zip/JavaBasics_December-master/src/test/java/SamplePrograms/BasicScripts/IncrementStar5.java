package SamplePrograms.BasicScripts;

public class IncrementStar5 {
	public static void main(String[] args) {
		int i, j, k;
		for (i = 9; i <= 9; i--) {
			for (j = 1; j >= i; j--) {
				System.out.print(" ");
				
			}
			System.out.println("*");
		}
	}
}
