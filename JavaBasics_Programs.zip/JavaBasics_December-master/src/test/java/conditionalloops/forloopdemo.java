package conditionalloops;

public class forloopdemo {
    public static void main(String[] args) {

        for (int index = 1; index <= 6; index++) {
            System.out.println("Index is incrementing: " + index);
        }
        System.out.println("-----------------------------------");

        for (int index2= 6; index2 >= 1; index2--) {
            System.out.println("Index is decrementing: " + index2);
        }

    }
}
