package SamplePrograms.StringFunctions;

public class StringBuilderSample {

    public static void main(String[] args) {
        StringBuilder demo2 = new StringBuilder("Hello");
        System.out.println(demo2);
        demo2 = new StringBuilder("Bye");
        System.out.println(demo2);

        String sam = "james";
        String sam2 = "james2";
        System.out.println(sam.concat(sam2));

    }

}
