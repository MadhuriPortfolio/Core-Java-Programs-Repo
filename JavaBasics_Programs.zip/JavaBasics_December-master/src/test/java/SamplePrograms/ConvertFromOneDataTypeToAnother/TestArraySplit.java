package SamplePrograms.ConvertFromOneDataTypeToAnother;

public class TestArraySplit {

	public static void main(String[] args) {
		String name = "sample";
		char[] test = name.toCharArray();
		for (int i = 0; i < test.length; i++) {
			System.out.println(test[i]);
		}
	}

}
