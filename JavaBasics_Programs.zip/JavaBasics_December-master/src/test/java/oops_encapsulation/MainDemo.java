package oops_encapsulation;

public class MainDemo {

    public static void main(String[] args) {
        EncapsulationDemo encapsulationdemo = new EncapsulationDemo();
        encapsulationdemo.setMobilenumber(893962446);
        System.out.println(encapsulationdemo.getMobilenumber());
        System.out.println(encapsulationdemo.getOrderid());



    }
}
