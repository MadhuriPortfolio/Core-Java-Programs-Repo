package SamplePrograms.ConvertFromOneDataTypeToAnother;

public class IntegertoString {

	public static void main(String[] args) {
		// double a =100.12;
		int c = 101;
		String b = String.valueOf(c);
		System.out.println(b);
	}

}
