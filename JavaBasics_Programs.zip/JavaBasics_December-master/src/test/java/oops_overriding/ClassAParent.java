package oops_overriding;

public class ClassAParent {

    public void arithmeticOperation(int a , int b) {
        int result = a + b;
        System.out.println("from parent class : " + result);
    }
}
