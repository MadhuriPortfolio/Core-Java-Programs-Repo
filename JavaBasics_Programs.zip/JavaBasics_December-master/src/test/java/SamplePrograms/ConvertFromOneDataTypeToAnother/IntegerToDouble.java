package SamplePrograms.ConvertFromOneDataTypeToAnother;

public class IntegerToDouble {
	public static void main(String[] args) {
		Integer obj = new Integer(5);
		double d = obj.doubleValue();
		System.out.println("Value of d = " + d);
	}
}
