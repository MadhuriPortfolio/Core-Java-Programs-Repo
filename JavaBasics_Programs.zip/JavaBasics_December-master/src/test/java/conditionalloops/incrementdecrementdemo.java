package conditionalloops;

public class incrementdecrementdemo {

    public static void main(String[] args) {
        int i =0;
        System.out.println("brefore : " +i);
        System.out.println(i++);//post increment
        System.out.println(i);//post increment print
        System.out.println(++i);//pre increment
        System.out.println(i);//pre increment print

    }
}
