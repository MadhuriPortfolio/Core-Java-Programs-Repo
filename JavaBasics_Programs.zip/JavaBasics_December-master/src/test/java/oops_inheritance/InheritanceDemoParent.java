package oops_inheritance;

public class InheritanceDemoParent {

    String name ="parent";

    public void additionOperation(){
        int a =1;
        int b =2;
        int result = a+b;
        System.out.println("result of addition operation : " + result);
    }
}
