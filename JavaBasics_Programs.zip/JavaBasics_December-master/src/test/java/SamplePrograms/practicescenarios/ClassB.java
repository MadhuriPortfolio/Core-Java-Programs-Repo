package SamplePrograms.practicescenarios;

public class ClassB {

	public String display(String x) {
		return x;
	}
}
