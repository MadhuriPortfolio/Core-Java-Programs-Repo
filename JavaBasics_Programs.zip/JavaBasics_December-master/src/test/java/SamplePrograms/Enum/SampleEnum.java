package SamplePrograms.Enum;

public class SampleEnum {
	public enum days {
		monday, tuesday, wednesday, thursday, friday
	};

	public static void main(String[] args) {
		//for (days d : days.values()) {
				System.out.println(days.monday);
		//}
	}
}
