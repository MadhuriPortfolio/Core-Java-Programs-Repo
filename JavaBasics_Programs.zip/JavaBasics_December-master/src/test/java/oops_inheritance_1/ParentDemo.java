package oops_inheritance_1;

public class ParentDemo {

    String name ="data_parent";

    public void arithmeticOperation(){
        String data = "from parent" ;
        System.out.println(data);
    }

}
