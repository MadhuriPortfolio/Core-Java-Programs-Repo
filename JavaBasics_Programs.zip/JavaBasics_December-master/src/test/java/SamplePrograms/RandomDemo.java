package SamplePrograms;

import java.util.Random;

public class RandomDemo {

    public static void main(String[] args) {
        Random sample = new Random();
        System.out.println(sample.nextInt(100));

    }
}
