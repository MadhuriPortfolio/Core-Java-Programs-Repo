package conditionalloops;

public class doWhileLoopDemo {

    public static void main(String[] args) {
        int i =0;
        do{
            System.out.println("this is from do statement : " +i);
            i++;
        }while (i<=6);//0,1,2,3,4,5,6
    }
}
