package SamplePrograms.Demo_Reader;

import java.io.File;
import java.io.FileInputStream;
import java.util.Scanner;

public class BufferedInputStream {

	public static void main(String[] args) {
		Scanner in= new Scanner(System.in);
		System.out.println("Enter the number to check:");
		//original=in.nextInt();
		int num=in.nextInt();
		int n = num;
		
	}
}

