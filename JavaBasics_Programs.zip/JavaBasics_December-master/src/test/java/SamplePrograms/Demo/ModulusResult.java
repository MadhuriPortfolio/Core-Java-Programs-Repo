package SamplePrograms.Demo;

public class ModulusResult {

	public static void main(String[] args) {
		// this pulls in remainder
		int result = 5 % 2;
		System.out.println(result);
	}

}
