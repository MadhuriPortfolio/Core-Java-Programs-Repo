package SamplePrograms.ArrayDemo;

public class ArrayDemo2 {

	public static void main(String[] args) {
		// initialisation of 2D arrays
		int[][] darray = new int[2][2];
		darray[0][0] = 2;
		darray[0][1] = 3;
		darray[1][0] = 4;
		darray[1][1] = 5;
		System.out.println("the data in the 2d array :" + darray[0][1]);
	}

}
