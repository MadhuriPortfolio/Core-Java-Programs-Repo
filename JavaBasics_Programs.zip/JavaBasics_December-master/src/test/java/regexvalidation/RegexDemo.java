package regexvalidation;

public class RegexDemo {
    public static void main(String[] args) {
        String name = "hdfc";
        System.out.println(name.matches("[a-z]+"));
    }
}
